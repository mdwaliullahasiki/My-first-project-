package pattern;

import model.*;
import service.*;
import payment.*;
import exception.*;

import java.util.*;

/**
 * ShopObserver Interface - Observer Design Pattern
 */
public interface ShopObserver {
    void onOrderPlaced(Order order);
    void onLowStock(TShirt product, int remaining);
    void onNewCustomer(Customer customer);
}


/**
 * ShopManager - Singleton Design Pattern + Subject (Observer Pattern)
 * Central controller for the entire shop system
 * Demonstrates: Singleton, Observer, Facade patterns
 */
class ShopManager {
    // Singleton instance
    private static ShopManager instance;
    private static final Object LOCK = new Object();

    private final Inventory<Product> mainInventory;
    private final Map<String, Customer> customers;
    private final List<Order> allOrders;
    private final List<ShopObserver> observers;
    private DiscountStrategy activeDiscount;
    private double totalRevenue;

    // Private constructor (Singleton)
    private ShopManager() {
        this.mainInventory = new Inventory<>("Main Store");
        this.customers = new LinkedHashMap<>();
        this.allOrders = new ArrayList<>();
        this.observers = new ArrayList<>();
        this.activeDiscount = new NoDiscount();
        this.totalRevenue = 0.0;
    }

    // Thread-safe Singleton getInstance (Double-checked locking)
    public static ShopManager getInstance() {
        if (instance == null) {
            synchronized (LOCK) {
                if (instance == null) {
                    instance = new ShopManager();
                }
            }
        }
        return instance;
    }

    // Observer management
    public void addObserver(ShopObserver observer) { observers.add(observer); }
    public void removeObserver(ShopObserver observer) { observers.remove(observer); }

    private void notifyOrderPlaced(Order order) {
        observers.forEach(o -> o.onOrderPlaced(order));
    }
    private void notifyLowStock(TShirt product, int remaining) {
        observers.forEach(o -> o.onLowStock(product, remaining));
    }
    private void notifyNewCustomer(Customer customer) {
        observers.forEach(o -> o.onNewCustomer(customer));
    }

    // Product management
    public void addProduct(Product product) {
        mainInventory.addProduct(product);
    }

    // Customer management
    public Customer registerCustomer(Customer customer) {
        customers.put(customer.getCustomerId(), customer);
        notifyNewCustomer(customer);
        return customer;
    }

    public Customer findCustomer(String customerId) {
        Customer c = customers.get(customerId);
        if (c == null) throw new CustomerNotFoundException(customerId);
        return c;
    }

    // Place an order (Facade Pattern - hides complexity)
    public Order placeOrder(String customerId, Map<String, Integer> productQuantities,
                            PaymentProcessor payment) {
        Customer customer = findCustomer(customerId);
        Order order = new Order(customer);
        double totalDiscount = 0;

        for (Map.Entry<String, Integer> entry : productQuantities.entrySet()) {
            Product product = mainInventory.findById(entry.getKey());
            int qty = entry.getValue();

            // Check stock
            if (product instanceof TShirt) {
                TShirt tshirt = (TShirt) product;
                if (!tshirt.isInStock() || tshirt.getStockQuantity() < qty) {
                    throw new InsufficientStockException(product.getName(),
                        tshirt.getStockQuantity(), qty);
                }
                tshirt.reduceStock(qty);

                // Notify if low stock
                if (tshirt.getStockQuantity() <= 3) {
                    notifyLowStock(tshirt, tshirt.getStockQuantity());
                }
            }

            CartItem item = new CartItem(product, qty);
            // Apply active discount
            double discountedPrice = activeDiscount.applyDiscount(
                product.calculateFinalPrice(), customer, product
            );
            item.setDiscountedPrice(discountedPrice);
            totalDiscount += (product.calculateFinalPrice() - discountedPrice) * qty;
            order.addItem(item);
        }

        // Free shipping for premium customers
        if (customer instanceof PremiumCustomer && ((PremiumCustomer) customer).hasFreeShipping()) {
            order.setShippingCost(0);
        }

        order.setDiscount(totalDiscount);
        order.calculateTotals();

        // Process payment
        boolean paid = payment.processPayment(order.getGrandTotal(), customerId);
        if (!paid) {
            throw new PaymentFailedException("Payment processor declined the transaction");
        }

        order.setPaymentMethod(payment.getPaymentMethod());
        order.setStatus(Order.OrderStatus.CONFIRMED);

        // Update customer record
        customer.addOrder(order.getOrderId(), order.getGrandTotal());
        allOrders.add(order);
        totalRevenue += order.getGrandTotal();

        notifyOrderPlaced(order);
        return order;
    }

    // Set discount strategy (Strategy Pattern)
    public void setDiscountStrategy(DiscountStrategy strategy) {
        this.activeDiscount = strategy;
        System.out.println("Active discount: " + strategy.getDiscountName());
    }

    // Sales report
    public void printSalesReport() {
        System.out.println("\n╔══════════════════════════════════════╗");
        System.out.println("║         SHOP SALES REPORT            ║");
        System.out.println("╠══════════════════════════════════════╣");
        System.out.printf("║ Total Orders   : %-19d║%n", allOrders.size());
        System.out.printf("║ Total Revenue  : $%-18.2f║%n", totalRevenue);
        System.out.printf("║ Total Customers: %-19d║%n", customers.size());
        System.out.printf("║ Avg Order Value: $%-18.2f║%n",
            allOrders.isEmpty() ? 0 : totalRevenue / allOrders.size());
        System.out.println("╠══════════════════════════════════════╣");
        System.out.println("║  RECENT ORDERS:                      ║");
        allOrders.stream().limit(5).forEach(o ->
            System.out.printf("║  %-37s║%n",
                o.getOrderId() + " $" + String.format("%.2f", o.getGrandTotal()))
        );
        System.out.println("╚══════════════════════════════════════╝\n");
    }

    // Getters
    public Inventory<Product> getInventory() { return mainInventory; }
    public Collection<Customer> getAllCustomers() { return customers.values(); }
    public List<Order> getAllOrders() { return Collections.unmodifiableList(allOrders); }
    public double getTotalRevenue() { return totalRevenue; }
}
