package payment;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * CashPayment - implements PaymentProcessor (Interface Implementation)
 */
public class CashPayment implements PaymentProcessor {
    private double cashReceived;
    private double change;

    public CashPayment(double cashReceived) {
        this.cashReceived = cashReceived;
    }

    @Override
    public boolean processPayment(double amount, String customerId) {
        if (cashReceived >= amount) {
            change = cashReceived - amount;
            System.out.printf("Cash payment accepted. Change: $%.2f%n", change);
            return true;
        }
        System.out.println("Insufficient cash provided.");
        return false;
    }

    @Override
    public String getPaymentMethod() { return "CASH"; }

    @Override
    public double getTransactionFee(double amount) { return 0.0; } // No fee for cash

    @Override
    public String generateReceipt(double amount, String transactionId) {
        return String.format(
            "--- CASH RECEIPT ---\nTxn ID : %s\nAmount : $%.2f\nCash   : $%.2f\nChange : $%.2f\nDate   : %s",
            transactionId, amount, cashReceived, change,
            LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"))
        );
    }

    public double getChange() { return change; }
}


/**
 * CardPayment - implements PaymentProcessor
 */
class CardPayment implements PaymentProcessor {
    private String cardType;       // VISA, MASTERCARD, AMEX
    private String maskedCardNumber;
    private boolean approved;

    public CardPayment(String cardType, String cardNumber) {
        this.cardType = cardType;
        // Mask card number - show only last 4 digits
        this.maskedCardNumber = "**** **** **** " + cardNumber.substring(cardNumber.length() - 4);
        this.approved = false;
    }

    @Override
    public boolean processPayment(double amount, String customerId) {
        // Simulate card authorization
        if (amount > 0 && amount < 10000) {
            approved = true;
            System.out.printf("Card payment authorized: %s (%s)%n", cardType, maskedCardNumber);
            return true;
        }
        System.out.println("Card payment declined.");
        return false;
    }

    @Override
    public String getPaymentMethod() { return "CARD - " + cardType; }

    @Override
    public double getTransactionFee(double amount) {
        // AMEX charges 2.5%, others 1.5%
        return "AMEX".equals(cardType) ? amount * 0.025 : amount * 0.015;
    }

    @Override
    public String generateReceipt(double amount, String transactionId) {
        return String.format(
            "--- CARD RECEIPT ---\nTxn ID  : %s\nCard    : %s (%s)\nAmount  : $%.2f\nFee     : $%.2f\nTotal   : $%.2f\nStatus  : %s\nDate    : %s",
            transactionId, cardType, maskedCardNumber, amount,
            getTransactionFee(amount), amount + getTransactionFee(amount),
            approved ? "APPROVED" : "DECLINED",
            java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"))
        );
    }
}


/**
 * DigitalWalletPayment - implements PaymentProcessor
 */
class DigitalWalletPayment implements PaymentProcessor {
    private String walletType;     // PAYPAL, STRIPE, BKASH
    private String walletId;
    private double walletBalance;

    public DigitalWalletPayment(String walletType, String walletId, double balance) {
        this.walletType = walletType;
        this.walletId = walletId;
        this.walletBalance = balance;
    }

    @Override
    public boolean processPayment(double amount, String customerId) {
        double totalWithFee = amount + getTransactionFee(amount);
        if (walletBalance >= totalWithFee) {
            walletBalance -= totalWithFee;
            System.out.printf("%s payment successful. Remaining balance: $%.2f%n", walletType, walletBalance);
            return true;
        }
        System.out.println("Insufficient wallet balance.");
        return false;
    }

    @Override
    public String getPaymentMethod() { return walletType; }

    @Override
    public double getTransactionFee(double amount) { return amount * 0.02; } // 2% fee

    @Override
    public String generateReceipt(double amount, String transactionId) {
        return String.format(
            "--- DIGITAL WALLET RECEIPT ---\nTxn ID  : %s\nWallet  : %s (%s)\nAmount  : $%.2f\nFee     : $%.2f\nBalance : $%.2f\nDate    : %s",
            transactionId, walletType, walletId, amount,
            getTransactionFee(amount), walletBalance,
            java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"))
        );
    }

    public double getWalletBalance() { return walletBalance; }
}
