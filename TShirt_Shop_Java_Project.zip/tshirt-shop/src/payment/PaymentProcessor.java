package payment;

/**
 * PaymentProcessor Interface - Demonstrates Interface concept
 */
public interface PaymentProcessor {
    boolean processPayment(double amount, String customerId);
    String getPaymentMethod();
    double getTransactionFee(double amount);
    String generateReceipt(double amount, String transactionId);

    // Default method (Java 8+ feature)
    default String getPaymentStatus(boolean success) {
        return success ? "PAYMENT_SUCCESS" : "PAYMENT_FAILED";
    }
}
