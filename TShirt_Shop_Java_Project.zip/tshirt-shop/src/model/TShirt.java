package model;

/**
 * TShirt class - extends Product (Inheritance)
 * Demonstrates: Inheritance, Encapsulation, Method Overriding (Polymorphism)
 */
public class TShirt extends Product {

    public enum Size { XS, S, M, L, XL, XXL }
    public enum Gender { MEN, WOMEN, UNISEX, KIDS }
    public enum Material { COTTON, POLYESTER, LINEN, BLEND, ORGANIC_COTTON }

    private Size size;
    private String color;
    private Gender gender;
    private Material material;
    private int stockQuantity;
    private double taxRate;

    // Constructor
    public TShirt(String name, double price, String description,
                  Size size, String color, Gender gender, Material material, int stockQuantity) {
        super(name, price, description);
        this.size = size;
        this.color = color;
        this.gender = gender;
        this.material = material;
        this.stockQuantity = stockQuantity;
        this.taxRate = 0.05; // 5% tax
    }

    // Overriding abstract methods (Polymorphism)
    @Override
    public String getCategory() {
        return "T-Shirt";
    }

    @Override
    public double calculateFinalPrice() {
        return getPrice() * (1 + taxRate);
    }

    @Override
    public String getProductDetails() {
        return String.format(
            "Size: %s | Color: %s | Gender: %s | Material: %s | Stock: %d",
            size, color, gender, material, stockQuantity
        );
    }

    // Business logic methods
    public boolean isInStock() {
        return stockQuantity > 0 && isAvailable();
    }

    public void reduceStock(int quantity) {
        if (quantity > stockQuantity) {
            throw new IllegalStateException(
                "Insufficient stock! Available: " + stockQuantity + ", Requested: " + quantity
            );
        }
        stockQuantity -= quantity;
        if (stockQuantity == 0) setAvailable(false);
    }

    public void addStock(int quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be positive");
        stockQuantity += quantity;
        setAvailable(true);
    }

    // Getters and Setters
    public Size getSize() { return size; }
    public void setSize(Size size) { this.size = size; }
    public String getColor() { return color; }
    public void setColor(String color) { this.color = color; }
    public Gender getGender() { return gender; }
    public void setGender(Gender gender) { this.gender = gender; }
    public Material getMaterial() { return material; }
    public void setMaterial(Material material) { this.material = material; }
    public int getStockQuantity() { return stockQuantity; }
    public double getTaxRate() { return taxRate; }
    public void setTaxRate(double taxRate) { this.taxRate = taxRate; }

    @Override
    public String toString() {
        return String.format("[%s] %s (%s/%s) - $%.2f [Stock: %d]",
            getProductId(), getName(), size, color, calculateFinalPrice(), stockQuantity);
    }
}
