package model;

/**
 * Abstract base class for all products in the T-Shirt Shop.
 * Demonstrates: Abstraction, Encapsulation
 */
public abstract class Product implements Comparable<Product> {
    private static int idCounter = 1000;

    private final String productId;
    private String name;
    private double price;
    private String description;
    private boolean available;

    // Constructor
    public Product(String name, double price, String description) {
        this.productId = "PRD-" + (idCounter++);
        this.name = name;
        this.price = price;
        this.description = description;
        this.available = true;
    }

    // Abstract methods - must be implemented by subclasses (Abstraction)
    public abstract String getCategory();
    public abstract double calculateFinalPrice();
    public abstract String getProductDetails();

    // Concrete method (Template Method Pattern)
    public final String getFullInfo() {
        return String.format(
            "=== PRODUCT INFO ===\n" +
            "ID       : %s\n" +
            "Category : %s\n" +
            "Name     : %s\n" +
            "Price    : $%.2f\n" +
            "Final    : $%.2f\n" +
            "Details  : %s\n" +
            "Status   : %s\n" +
            "===================",
            productId, getCategory(), name, price,
            calculateFinalPrice(), description,
            available ? "In Stock" : "Out of Stock"
        );
    }

    // Comparable implementation for sorting
    @Override
    public int compareTo(Product other) {
        return Double.compare(this.calculateFinalPrice(), other.calculateFinalPrice());
    }

    @Override
    public String toString() {
        return String.format("[%s] %s - $%.2f", productId, name, calculateFinalPrice());
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Product)) return false;
        Product other = (Product) obj;
        return this.productId.equals(other.productId);
    }

    @Override
    public int hashCode() {
        return productId.hashCode();
    }

    // Getters and Setters (Encapsulation)
    public String getProductId() { return productId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public double getPrice() { return price; }
    public void setPrice(double price) {
        if (price < 0) throw new IllegalArgumentException("Price cannot be negative");
        this.price = price;
    }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }
}
