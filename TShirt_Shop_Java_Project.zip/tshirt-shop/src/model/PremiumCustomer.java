package model;

/**
 * PremiumCustomer - extends Customer (Inheritance + Polymorphism)
 */
public class PremiumCustomer extends Customer {

    private String membershipId;
    private String membershipType; // MONTHLY, ANNUAL
    private double membershipFee;
    private boolean hasEarlyAccess;
    private boolean hasFreeShipping;
    private int bonusPointsMultiplier;

    public PremiumCustomer(String name, String email, String phone,
                            String address, String membershipType) {
        super(name, email, phone, address);
        this.membershipId = "PREM-" + System.currentTimeMillis() % 10000;
        this.membershipType = membershipType;
        this.hasEarlyAccess = true;
        this.hasFreeShipping = true;
        this.bonusPointsMultiplier = 3;

        if ("ANNUAL".equalsIgnoreCase(membershipType)) {
            this.membershipFee = 99.99;
        } else {
            this.membershipFee = 9.99;
        }
    }

    // Override discount (Polymorphism)
    @Override
    public double getDiscountRate() {
        double baseDiscount = super.getDiscountRate();
        return baseDiscount + 0.10; // Premium gets extra 10%
    }

    @Override
    public String getCustomerTier() {
        return "PREMIUM-" + super.getCustomerTier();
    }

    public String getMembershipDetails() {
        return String.format(
            "=== PREMIUM MEMBERSHIP ===\n" +
            "Membership ID  : %s\n" +
            "Type           : %s\n" +
            "Monthly Fee    : $%.2f\n" +
            "Early Access   : %s\n" +
            "Free Shipping  : %s\n" +
            "Points Bonus   : %dx\n" +
            "Discount Rate  : %.0f%%\n" +
            "==========================",
            membershipId, membershipType, membershipFee,
            hasEarlyAccess ? "Yes" : "No",
            hasFreeShipping ? "Yes" : "No",
            bonusPointsMultiplier,
            getDiscountRate() * 100
        );
    }

    // Getters
    public String getMembershipId() { return membershipId; }
    public String getMembershipType() { return membershipType; }
    public double getMembershipFee() { return membershipFee; }
    public boolean hasEarlyAccess() { return hasEarlyAccess; }
    public boolean hasFreeShipping() { return hasFreeShipping; }
    public int getBonusPointsMultiplier() { return bonusPointsMultiplier; }

    @Override
    public String toString() {
        return "[PREMIUM] " + super.toString();
    }
}
