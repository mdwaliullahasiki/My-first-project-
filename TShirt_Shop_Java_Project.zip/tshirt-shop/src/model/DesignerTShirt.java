package model;

/**
 * DesignerTShirt - extends TShirt (Multi-level Inheritance)
 * Demonstrates: Multi-level Inheritance, Method Overriding
 */
public class DesignerTShirt extends TShirt {

    private String designerName;
    private String collection;
    private int limitedEditionNumber;
    private int totalEditions;
    private double premiumMarkup;   // extra % for luxury
    private boolean isCertified;

    public DesignerTShirt(String name, double price, String description,
                          Size size, String color, Gender gender, Material material,
                          int stockQuantity, String designerName, String collection,
                          int limitedEditionNumber, int totalEditions, double premiumMarkup) {
        super(name, price, description, size, color, gender, material, stockQuantity);
        this.designerName = designerName;
        this.collection = collection;
        this.limitedEditionNumber = limitedEditionNumber;
        this.totalEditions = totalEditions;
        this.premiumMarkup = premiumMarkup;
        this.isCertified = true;
    }

    // Overriding to add premium markup (Polymorphism)
    @Override
    public String getCategory() {
        return "Designer T-Shirt";
    }

    @Override
    public double calculateFinalPrice() {
        double baseWithTax = super.calculateFinalPrice();
        return baseWithTax * (1 + premiumMarkup);
    }

    @Override
    public String getProductDetails() {
        return super.getProductDetails() + String.format(
            "\nDesigner: %s | Collection: %s | Edition: %d/%d | Certified: %s",
            designerName, collection, limitedEditionNumber, totalEditions,
            isCertified ? "Yes" : "No"
        );
    }

    public String getCertificateInfo() {
        return String.format(
            "CERTIFICATE OF AUTHENTICITY\n" +
            "Designer : %s\n" +
            "Collection: %s\n" +
            "Edition  : #%d of %d\n" +
            "Product  : %s",
            designerName, collection, limitedEditionNumber, totalEditions, getName()
        );
    }

    public boolean isRare() {
        return totalEditions <= 50;
    }

    // Getters and Setters
    public String getDesignerName() { return designerName; }
    public String getCollection() { return collection; }
    public int getLimitedEditionNumber() { return limitedEditionNumber; }
    public int getTotalEditions() { return totalEditions; }
    public double getPremiumMarkup() { return premiumMarkup; }
    public boolean isCertified() { return isCertified; }
    public void setIsCertified(boolean certified) { isCertified = certified; }

    @Override
    public String toString() {
        return String.format("[DESIGNER] %s by %s (%s Collection) - $%.2f [#%d/%d]",
            getName(), designerName, collection, calculateFinalPrice(),
            limitedEditionNumber, totalEditions);
    }
}
