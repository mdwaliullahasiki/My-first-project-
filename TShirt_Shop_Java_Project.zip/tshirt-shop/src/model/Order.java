package model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * CartItem - represents a product and quantity in the cart
 */
class CartItem {
    private Product product;
    private int quantity;
    private double unitPrice;
    private double discountedPrice;

    public CartItem(Product product, int quantity) {
        this.product = product;
        this.quantity = quantity;
        this.unitPrice = product.calculateFinalPrice();
        this.discountedPrice = unitPrice;
    }

    public double getSubtotal() { return discountedPrice * quantity; }
    public Product getProduct() { return product; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public double getUnitPrice() { return unitPrice; }
    public double getDiscountedPrice() { return discountedPrice; }
    public void setDiscountedPrice(double price) { this.discountedPrice = price; }

    @Override
    public String toString() {
        return String.format("%-30s x%-3d @ $%.2f = $%.2f",
            product.getName(), quantity, discountedPrice, getSubtotal());
    }
}


/**
 * Order class - full order with status tracking
 */
public class Order {
    public enum OrderStatus {
        PENDING, CONFIRMED, PROCESSING, SHIPPED, DELIVERED, CANCELLED, REFUNDED
    }

    private final String orderId;
    private final Customer customer;
    private final List<CartItem> items;
    private OrderStatus status;
    private double subtotal;
    private double discount;
    private double shippingCost;
    private double tax;
    private double grandTotal;
    private String paymentMethod;
    private final LocalDateTime orderDate;
    private LocalDateTime deliveryDate;
    private String notes;

    public Order(Customer customer) {
        this.orderId = "ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        this.customer = customer;
        this.items = new ArrayList<>();
        this.status = OrderStatus.PENDING;
        this.orderDate = LocalDateTime.now();
        this.shippingCost = 5.99;
    }

    public void addItem(CartItem item) {
        items.add(item);
    }

    public void calculateTotals() {
        subtotal = items.stream().mapToDouble(CartItem::getSubtotal).sum();
        grandTotal = subtotal + shippingCost - discount;
    }

    public String generateInvoice() {
        StringBuilder sb = new StringBuilder();
        sb.append("╔══════════════════════════════════════════╗\n");
        sb.append("║         TSHIRT SHOP - INVOICE            ║\n");
        sb.append("╚══════════════════════════════════════════╝\n");
        sb.append(String.format("Order ID    : %s\n", orderId));
        sb.append(String.format("Date        : %s\n",
            orderDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"))));
        sb.append(String.format("Customer    : %s\n", customer.getName()));
        sb.append(String.format("Status      : %s\n", status));
        sb.append("──────────────────────────────────────────\n");
        sb.append("ITEMS:\n");
        for (CartItem item : items) {
            sb.append("  ").append(item).append("\n");
        }
        sb.append("──────────────────────────────────────────\n");
        sb.append(String.format("Subtotal    :  $%8.2f\n", subtotal));
        sb.append(String.format("Discount    : -$%8.2f\n", discount));
        sb.append(String.format("Shipping    :  $%8.2f\n", shippingCost));
        sb.append("──────────────────────────────────────────\n");
        sb.append(String.format("GRAND TOTAL :  $%8.2f\n", grandTotal));
        sb.append("══════════════════════════════════════════\n");
        return sb.toString();
    }

    // Getters and Setters
    public String getOrderId() { return orderId; }
    public Customer getCustomer() { return customer; }
    public List<CartItem> getItems() { return new ArrayList<>(items); }
    public OrderStatus getStatus() { return status; }
    public void setStatus(OrderStatus status) { this.status = status; }
    public double getSubtotal() { return subtotal; }
    public double getDiscount() { return discount; }
    public void setDiscount(double discount) { this.discount = discount; }
    public double getShippingCost() { return shippingCost; }
    public void setShippingCost(double cost) { this.shippingCost = cost; }
    public double getGrandTotal() { return grandTotal; }
    public String getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(String method) { this.paymentMethod = method; }
    public LocalDateTime getOrderDate() { return orderDate; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    @Override
    public String toString() {
        return String.format("[%s] Customer: %s | Total: $%.2f | Status: %s",
            orderId, customer.getName(), grandTotal, status);
    }
}
