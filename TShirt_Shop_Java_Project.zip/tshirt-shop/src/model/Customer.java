package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Customer class - Encapsulation + Inheritance base
 */
public class Customer {
    private static int customerCounter = 5000;

    private final String customerId;
    private String name;
    private String email;
    private String phone;
    private String address;
    private double totalSpent;
    private List<String> orderHistory;
    private int loyaltyPoints;

    public Customer(String name, String email, String phone, String address) {
        this.customerId = "CUST-" + (customerCounter++);
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.totalSpent = 0.0;
        this.orderHistory = new ArrayList<>();
        this.loyaltyPoints = 0;
    }

    // Business logic
    public void addOrder(String orderId, double amount) {
        orderHistory.add(orderId);
        totalSpent += amount;
        loyaltyPoints += (int)(amount / 10); // 1 point per $10 spent
    }

    public String getCustomerTier() {
        if (totalSpent >= 500) return "GOLD";
        if (totalSpent >= 200) return "SILVER";
        return "BRONZE";
    }

    public double getDiscountRate() {
        switch (getCustomerTier()) {
            case "GOLD":   return 0.15;
            case "SILVER": return 0.10;
            default:       return 0.05;
        }
    }

    public String getCustomerProfile() {
        return String.format(
            "Customer ID : %s\nName        : %s\nEmail       : %s\n" +
            "Phone       : %s\nTier        : %s\nTotal Spent : $%.2f\n" +
            "Loyalty Pts : %d\nOrders      : %d",
            customerId, name, email, phone, getCustomerTier(),
            totalSpent, loyaltyPoints, orderHistory.size()
        );
    }

    // Getters and Setters
    public String getCustomerId() { return customerId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public double getTotalSpent() { return totalSpent; }
    public int getLoyaltyPoints() { return loyaltyPoints; }
    public List<String> getOrderHistory() { return new ArrayList<>(orderHistory); }

    @Override
    public String toString() {
        return String.format("[%s] %s (%s) - %s Tier", customerId, name, email, getCustomerTier());
    }
}
