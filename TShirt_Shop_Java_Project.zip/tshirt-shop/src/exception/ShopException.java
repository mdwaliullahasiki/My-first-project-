package exception;

/**
 * Custom Exception Hierarchy - demonstrates Exception Handling in OOP
 */

// Base exception for all shop-related exceptions
public class ShopException extends RuntimeException {
    private final String errorCode;

    public ShopException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }

    public ShopException(String message, String errorCode, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
    }

    public String getErrorCode() { return errorCode; }

    @Override
    public String toString() {
        return String.format("[%s] %s", errorCode, getMessage());
    }
}
