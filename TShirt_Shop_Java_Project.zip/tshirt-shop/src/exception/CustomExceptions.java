package exception;

public class ProductNotFoundException extends ShopException {
    public ProductNotFoundException(String productId) {
        super("Product not found: " + productId, "ERR-001");
    }
}

class InsufficientStockException extends ShopException {
    private final int available;
    private final int requested;

    public InsufficientStockException(String productName, int available, int requested) {
        super(String.format("Insufficient stock for '%s'. Available: %d, Requested: %d",
              productName, available, requested), "ERR-002");
        this.available = available;
        this.requested = requested;
    }

    public int getAvailable() { return available; }
    public int getRequested() { return requested; }
}

class PaymentFailedException extends ShopException {
    public PaymentFailedException(String reason) {
        super("Payment failed: " + reason, "ERR-003");
    }
}

class CustomerNotFoundException extends ShopException {
    public CustomerNotFoundException(String customerId) {
        super("Customer not found: " + customerId, "ERR-004");
    }
}

class InvalidOrderException extends ShopException {
    public InvalidOrderException(String reason) {
        super("Invalid order: " + reason, "ERR-005");
    }
}

class InventoryException extends ShopException {
    public InventoryException(String message) {
        super(message, "ERR-006");
    }
}
