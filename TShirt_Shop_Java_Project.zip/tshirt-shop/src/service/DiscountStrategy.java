package service;

import model.Product;
import model.Customer;
import model.PremiumCustomer;

/**
 * DiscountStrategy Interface - Strategy Design Pattern
 */
public interface DiscountStrategy {
    double applyDiscount(double originalPrice, Customer customer, Product product);
    String getDiscountName();
    String getDiscountDescription();
}


/**
 * SeasonalDiscount - implements DiscountStrategy
 */
class SeasonalDiscount implements DiscountStrategy {
    private String season;
    private double discountPercent;

    public SeasonalDiscount(String season, double discountPercent) {
        this.season = season;
        this.discountPercent = discountPercent;
    }

    @Override
    public double applyDiscount(double originalPrice, Customer customer, Product product) {
        return originalPrice * (1 - discountPercent);
    }

    @Override
    public String getDiscountName() { return season + " Sale"; }

    @Override
    public String getDiscountDescription() {
        return String.format("%s discount: %.0f%% off all products", season, discountPercent * 100);
    }
}


/**
 * MemberDiscount - implements DiscountStrategy (Customer tier-based)
 */
class MemberDiscount implements DiscountStrategy {

    @Override
    public double applyDiscount(double originalPrice, Customer customer, Product product) {
        double discount = customer.getDiscountRate();
        return originalPrice * (1 - discount);
    }

    @Override
    public String getDiscountName() { return "Member Discount"; }

    @Override
    public String getDiscountDescription() {
        return "Discount based on customer tier: Bronze 5%, Silver 10%, Gold 15%, Premium +10%";
    }
}


/**
 * BulkDiscount - implements DiscountStrategy
 */
class BulkDiscount implements DiscountStrategy {
    private int minQuantity;
    private double discountPercent;

    public BulkDiscount(int minQuantity, double discountPercent) {
        this.minQuantity = minQuantity;
        this.discountPercent = discountPercent;
    }

    @Override
    public double applyDiscount(double originalPrice, Customer customer, Product product) {
        return originalPrice * (1 - discountPercent);
    }

    @Override
    public String getDiscountName() { return "Bulk Discount"; }

    @Override
    public String getDiscountDescription() {
        return String.format("Buy %d+ items: %.0f%% off", minQuantity, discountPercent * 100);
    }

    public int getMinQuantity() { return minQuantity; }
}


/**
 * NoDiscount - Null Object Pattern
 */
class NoDiscount implements DiscountStrategy {
    @Override
    public double applyDiscount(double originalPrice, Customer customer, Product product) {
        return originalPrice;
    }

    @Override
    public String getDiscountName() { return "No Discount"; }

    @Override
    public String getDiscountDescription() { return "Full price applies"; }
}
