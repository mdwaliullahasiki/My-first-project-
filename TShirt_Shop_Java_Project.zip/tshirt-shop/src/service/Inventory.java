package service;

import model.Product;
import model.TShirt;
import exception.ProductNotFoundException;
import exception.InventoryException;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Inventory<T> - Generic Inventory class (Generics demonstration)
 * Demonstrates: Generics, Collections, Stream API
 */
public class Inventory<T extends Product> {

    private final Map<String, T> products;
    private final String inventoryName;

    public Inventory(String inventoryName) {
        this.inventoryName = inventoryName;
        this.products = new LinkedHashMap<>();
    }

    // Add product
    public void addProduct(T product) {
        if (products.containsKey(product.getProductId())) {
            throw new InventoryException("Product already exists: " + product.getProductId());
        }
        products.put(product.getProductId(), product);
        System.out.println("✓ Added to inventory: " + product.getName());
    }

    // Remove product
    public T removeProduct(String productId) {
        T product = products.remove(productId);
        if (product == null) throw new ProductNotFoundException(productId);
        System.out.println("✓ Removed from inventory: " + product.getName());
        return product;
    }

    // Find by ID
    public T findById(String productId) {
        T product = products.get(productId);
        if (product == null) throw new ProductNotFoundException(productId);
        return product;
    }

    // Search by name (case-insensitive)
    public List<T> searchByName(String keyword) {
        return products.values().stream()
            .filter(p -> p.getName().toLowerCase().contains(keyword.toLowerCase()))
            .collect(Collectors.toList());
    }

    // Filter available products
    public List<T> getAvailableProducts() {
        return products.values().stream()
            .filter(Product::isAvailable)
            .sorted()  // uses Comparable
            .collect(Collectors.toList());
    }

    // Filter by price range
    public List<T> getByPriceRange(double min, double max) {
        return products.values().stream()
            .filter(p -> p.calculateFinalPrice() >= min && p.calculateFinalPrice() <= max)
            .sorted()
            .collect(Collectors.toList());
    }

    // Filter TShirts by size (using instanceof check)
    public List<T> getBySize(TShirt.Size size) {
        return products.values().stream()
            .filter(p -> p instanceof TShirt && ((TShirt) p).getSize() == size)
            .collect(Collectors.toList());
    }

    // Get most expensive product
    public Optional<T> getMostExpensive() {
        return products.values().stream().max(Comparator.naturalOrder());
    }

    // Get cheapest product
    public Optional<T> getCheapest() {
        return products.values().stream().min(Comparator.naturalOrder());
    }

    // Total inventory value
    public double getTotalInventoryValue() {
        return products.values().stream()
            .mapToDouble(p -> p.calculateFinalPrice())
            .sum();
    }

    // Display inventory table
    public void displayInventory() {
        System.out.println("\n╔═══════════════════════════════════════════════════════════════╗");
        System.out.printf("║  INVENTORY: %-50s║%n", inventoryName);
        System.out.println("╠═══════════════════════════════════════════════════════════════╣");
        System.out.printf("║ %-12s %-25s %-10s %-8s ║%n", "Product ID", "Name", "Price", "Stock");
        System.out.println("╠═══════════════════════════════════════════════════════════════╣");

        for (T product : products.values()) {
            String stock = "N/A";
            if (product instanceof TShirt) {
                stock = String.valueOf(((TShirt) product).getStockQuantity());
            }
            System.out.printf("║ %-12s %-25s $%-9.2f %-8s ║%n",
                product.getProductId(),
                product.getName().length() > 24 ? product.getName().substring(0, 22) + ".." : product.getName(),
                product.calculateFinalPrice(),
                stock
            );
        }

        System.out.println("╠═══════════════════════════════════════════════════════════════╣");
        System.out.printf("║  Total Products: %-5d  Total Value: $%-22.2f║%n",
            products.size(), getTotalInventoryValue());
        System.out.println("╚═══════════════════════════════════════════════════════════════╝\n");
    }

    public int getProductCount() { return products.size(); }
    public String getInventoryName() { return inventoryName; }
    public Collection<T> getAllProducts() { return Collections.unmodifiableCollection(products.values()); }
    public boolean containsProduct(String productId) { return products.containsKey(productId); }
}
