import model.*;
import model.TShirt.*;
import service.*;
import payment.*;
import pattern.*;
import exception.*;

import java.util.*;

/**
 * ┌─────────────────────────────────────────────────────────────────┐
 * │          T-SHIRT SHOP MANAGEMENT SYSTEM - MAIN DEMO             │
 * │          OOP Concepts: Inheritance, Polymorphism,               │
 * │          Encapsulation, Abstraction, Interfaces,                │
 * │          Generics, Exception Handling, Design Patterns          │
 * └─────────────────────────────────────────────────────────────────┘
 */
public class Main {

    public static void main(String[] args) {

        System.out.println("\n▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓");
        System.out.println("▓       T-SHIRT SHOP MANAGEMENT SYSTEM v1.0                 ▓");
        System.out.println("▓       Powered by Java OOP                                 ▓");
        System.out.println("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓\n");

        // ─── Singleton Pattern ───
        ShopManager shop = ShopManager.getInstance();

        // ─── Observer Pattern: Add notification listener ───
        shop.addObserver(new ShopObserver() {
            @Override
            public void onOrderPlaced(Order order) {
                System.out.println("📦 [NOTIFICATION] New order placed: " + order.getOrderId()
                    + " | Total: $" + String.format("%.2f", order.getGrandTotal()));
            }
            @Override
            public void onLowStock(TShirt product, int remaining) {
                System.out.println("⚠️  [ALERT] Low stock: " + product.getName()
                    + " - Only " + remaining + " left!");
            }
            @Override
            public void onNewCustomer(Customer customer) {
                System.out.println("👤 [WELCOME] New customer registered: " + customer.getName());
            }
        });

        // ══════════════════════════════════════
        // SECTION 1: INVENTORY SETUP (Polymorphism)
        // ══════════════════════════════════════
        System.out.println("\n═══ SECTION 1: Setting Up Inventory ═══");

        // TShirt objects (Inheritance + Constructor)
        TShirt shirt1 = new TShirt("Classic White Tee", 19.99, "100% Cotton classic fit",
            Size.M, "White", Gender.UNISEX, Material.COTTON, 50);

        TShirt shirt2 = new TShirt("Urban Black Slim", 24.99, "Slim fit premium blend",
            Size.L, "Black", Gender.MEN, Material.BLEND, 30);

        TShirt shirt3 = new TShirt("Summer Floral Top", 22.99, "Lightweight summer design",
            Size.S, "Pink", Gender.WOMEN, Material.LINEN, 5); // Low stock for demo

        TShirt shirt4 = new TShirt("Kids Dino Print", 14.99, "Fun dinosaur prints for kids",
            Size.XS, "Green", Gender.KIDS, Material.ORGANIC_COTTON, 25);

        // DesignerTShirt (Multi-level Inheritance)
        DesignerTShirt designerShirt = new DesignerTShirt(
            "Midnight Luxe Edition", 79.99, "Exclusive luxury designer piece",
            Size.L, "Midnight Blue", Gender.UNISEX, Material.ORGANIC_COTTON,
            10, "Alessandro Ferrari", "Autumn 2024",
            7, 100, 0.30  // 30% premium markup
        );

        // Add products (Polymorphism - Product reference)
        shop.addProduct(shirt1);
        shop.addProduct(shirt2);
        shop.addProduct(shirt3);
        shop.addProduct(shirt4);
        shop.addProduct(designerShirt);

        // Display inventory using generic inventory
        shop.getInventory().displayInventory();

        // ══════════════════════════════════════
        // SECTION 2: CUSTOMER REGISTRATION
        // ══════════════════════════════════════
        System.out.println("═══ SECTION 2: Customer Registration ═══");

        // Regular Customer (Encapsulation)
        Customer regularCustomer = new Customer("Rahim Uddin", "rahim@email.com",
            "01711-234567", "Dhaka, Bangladesh");
        shop.registerCustomer(regularCustomer);

        // Premium Customer (Inheritance + Polymorphism)
        PremiumCustomer premiumCustomer = new PremiumCustomer(
            "Sarah Khan", "sarah@email.com", "01912-345678",
            "Chittagong, Bangladesh", "ANNUAL"
        );
        shop.registerCustomer(premiumCustomer);

        System.out.println("\n" + regularCustomer.getCustomerProfile());
        System.out.println("\n" + premiumCustomer.getMembershipDetails());

        // ══════════════════════════════════════
        // SECTION 3: POLYMORPHISM DEMO
        // ══════════════════════════════════════
        System.out.println("\n═══ SECTION 3: Polymorphism Demo ═══");

        // Array of Products - Runtime Polymorphism
        Product[] products = {shirt1, shirt2, designerShirt};
        System.out.println("Dynamic method dispatch - calculateFinalPrice():");
        for (Product p : products) {
            System.out.printf("  %-25s Category: %-18s Price: $%.2f%n",
                p.getName(), p.getCategory(), p.calculateFinalPrice());
        }

        // ══════════════════════════════════════
        // SECTION 4: STRATEGY PATTERN - Discount
        // ══════════════════════════════════════
        System.out.println("\n═══ SECTION 4: Strategy Pattern (Discount) ═══");

        // Test different discount strategies
        DiscountStrategy memberDiscount = new MemberDiscount();
        System.out.println("Strategy: " + memberDiscount.getDiscountDescription());

        // ══════════════════════════════════════
        // SECTION 5: ORDER PLACEMENT + PAYMENT
        // ══════════════════════════════════════
        System.out.println("\n═══ SECTION 5: Order Processing ═══");

        // Set active discount strategy
        shop.setDiscountStrategy(memberDiscount);

        // Prepare order for regular customer - Cash payment
        Map<String, Integer> order1Items = new LinkedHashMap<>();
        order1Items.put(shirt1.getProductId(), 2);  // 2x Classic White Tee
        order1Items.put(shirt4.getProductId(), 1);  // 1x Kids Dino Print

        PaymentProcessor cashPayment = new CashPayment(100.00);

        try {
            Order order1 = shop.placeOrder(regularCustomer.getCustomerId(), order1Items, cashPayment);
            System.out.println("\n" + order1.generateInvoice());
        } catch (ShopException e) {
            System.out.println("Order failed: " + e);
        }

        // Premium customer order - Card payment (Polymorphism)
        Map<String, Integer> order2Items = new LinkedHashMap<>();
        order2Items.put(designerShirt.getProductId(), 1);
        order2Items.put(shirt2.getProductId(), 2);

        PaymentProcessor cardPayment = new CardPayment("VISA", "4111111111111234");

        try {
            Order order2 = shop.placeOrder(premiumCustomer.getCustomerId(), order2Items, cardPayment);
            System.out.println(order2.generateInvoice());
        } catch (ShopException e) {
            System.out.println("Order failed: " + e);
        }

        // ══════════════════════════════════════
        // SECTION 6: EXCEPTION HANDLING DEMO
        // ══════════════════════════════════════
        System.out.println("═══ SECTION 6: Exception Handling Demo ═══");

        // Test ProductNotFoundException
        try {
            shop.getInventory().findById("INVALID-ID");
        } catch (ProductNotFoundException e) {
            System.out.println("Caught: " + e);
        }

        // Test InsufficientStock
        try {
            Map<String, Integer> bigOrder = new HashMap<>();
            bigOrder.put(shirt3.getProductId(), 100); // Stock is only 5
            shop.placeOrder(regularCustomer.getCustomerId(), bigOrder, new CashPayment(9999));
        } catch (InsufficientStockException e) {
            System.out.println("Caught: " + e);
        }

        // ══════════════════════════════════════
        // SECTION 7: GENERICS + STREAM DEMO
        // ══════════════════════════════════════
        System.out.println("\n═══ SECTION 7: Generics & Collections ═══");

        System.out.println("Products in price range $15 - $30:");
        shop.getInventory().getByPriceRange(15, 30)
            .forEach(p -> System.out.println("  " + p));

        System.out.println("\nProducts by Size MEDIUM:");
        shop.getInventory().getBySize(Size.M)
            .forEach(p -> System.out.println("  " + p));

        shop.getInventory().getMostExpensive()
            .ifPresent(p -> System.out.println("\nMost Expensive: " + p));

        // ══════════════════════════════════════
        // SECTION 8: SALES REPORT
        // ══════════════════════════════════════
        shop.printSalesReport();

        System.out.println("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓");
        System.out.println("▓       SYSTEM DEMO COMPLETE                                ▓");
        System.out.println("▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓\n");
    }
}
